package vcmsa.ci.myflashcards

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        val btntrue = findViewById<Button>(R.id.btnTrue)
        val btnfalse = findViewById<Button>(R.id.btnfalse)
        val btnNext = findViewById<Button>(R.id.btnNext)
        val txtresults = findViewById<TextView>(R.id.txtresults)
        val txtQuestion = findViewById<TextView>(R.id.txtquestion)

        val questions = listOf(
            "the renaissance started in Germany." to false,
            "the world war I ended in 1920" to false,
            "the apartheid started in 1948 and then ended in 1994." to true,
            "the Berlin wall was built by the German democratic republic" to true,
            "Julius Caesar was a Roman dictator" to true
        )
        var score = 0
        var currentIndex = 0

        txtQuestion.text = questions[currentIndex].first

        fun checkAnswer(userAnswer: Boolean) {
            val correctAnswer = questions[currentIndex].second
            if (userAnswer == correctAnswer) {
                txtresults.text = "that's correct"
                score++
            } else {
                txtresults.text = "that's incorrect"
            }
        }
        fun nextQuestion() {
            currentIndex++
            if (currentIndex < questions.size) {
                txtQuestion.text = questions[currentIndex].first
                txtresults.text = ""
            } else {
                txtQuestion.text = "you have completed your quiz and this is your score: $score"
                btnfalse.isEnabled = false
                btntrue.isEnabled = false
                btnNext.isEnabled = false
            }
        }
        btnfalse.setOnClickListener { checkAnswer(true) }
        btntrue.setOnClickListener { checkAnswer(false) }
        btnNext.setOnClickListener { nextQuestion() }


        }
    }

